﻿Test 4
======

On this machine is a Microsoft SQL Server - it is installed as  the default instance.
There is a database named "AstronautDB" with a single table.
We want to retrieve data from this table.

TODO:
- implement the AstronaughtList mehtod to treturn astronauts for a specific filter and page size

NOTE:
- an empty filter criteria should return all rows (up to the page size)
- a page size of zero means there is no limit on the size of the page.