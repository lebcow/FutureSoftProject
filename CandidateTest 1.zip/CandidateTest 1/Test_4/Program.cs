﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Test_4
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                List<string> astonauts = AstronautList("John", 20);
                Debug.Assert(astonauts.Count == 16, "There should be 16 names containing John");
            }
            {
                List<string> astonauts = AstronautList("Alex", 10);
                Debug.Assert(astonauts.Count == 10, "There should be 10 names in the page");
            }
            {
                List<string> astonauts = AstronautList(String.Empty, 0);
                Debug.Assert(astonauts.Count >= 569, "There should be at least 569 names in total");
            }
            {
                List<string> astonauts = AstronautList(String.Empty, 200);
                Debug.Assert(astonauts.Count == 200, "There should be at least 200 names in the page");
            }
        }

        private static List<string> AstronautList(string filter, int pageSize)
        {
            List<string> Astronaut = new List<string>();

            using (AstronautDBEntities context = new AstronautDBEntities())
            {
                if (pageSize != 0)
                {
                    Astronaut = context.Astronauts
                                             .Where(a => (a.Name == filter && filter != string.Empty) || (a.Name != string.Empty && filter == string.Empty))
                                             .Take(pageSize)
                                             .Select(a => a.Name)
                                             .ToList();
                }
                else
                {
                    Astronaut = context.Astronauts
                                            .Where(a => (a.Name == filter && filter != string.Empty) || (a.Name != string.Empty && filter == string.Empty))
                                             .Select(a => a.Name)
                                            .ToList();
                }
            }

            return Astronaut;
        }
    }
}
