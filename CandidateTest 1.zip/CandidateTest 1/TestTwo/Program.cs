﻿using System.Diagnostics;

namespace Test_2
{
    class Program
    {
        static void Main(string[] args)
        {
            MyRectangle retangleOne = new MyRectangle() { X1 = 2, Y1 = 2, X2 = 6, Y2 = 7 };
            MyRectangle rectangleTwo = new MyRectangle() { X1 = 1, Y1 = 6, X2 = 3, Y2 = 8 };
            MyRectangle rectangleThree = new MyRectangle() { X1 = 7, Y1 = 2, X2 = 8, Y2 = 6 };
            MyRectangle rectangelFour = new MyRectangle() { X1 = 3, Y1 = 4, X2 = 5, Y2 = 6 };

            Debug.Assert(rectangleTwo.IsWhollyContainedIn(retangleOne) == false);
            Debug.Assert(rectangleThree.IsWhollyContainedIn(retangleOne) == false);
            Debug.Assert(rectangelFour.IsWhollyContainedIn(retangleOne) == true);
            Debug.Assert(retangleOne.IsWhollyContainedIn(rectangelFour) == false);

           
        }

    }
};