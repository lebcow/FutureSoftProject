﻿Test Two
========

In this test we need to determine if the rectangles are wholly contained within other rectangles.
For example, rectangle #1 is wholly contained in rectangle 2# (#2 is, however, not wholly contained in #1)

-------------------------------------
|                              #2   |
|   -----------------------         |
|	|					  |         |
|	|                     |         |
|	|      #1             |         |
|	|                     |         |
|	|                     |         |
|   -----------------------         |
|                                   |
-------------------------------------

(Note that even though #1 is wholly contained in #2, #2 is not wholly contained in 1#.)

Whereas in #1 is NOT wholly contained in #2 in the following scenario:

-------------------------------------
|  									|
|									|
|									|
|									|
|									||                              #2   |

|	----------------				|
|  	|			   |		        |
|   |			   |	            |
----|      #1	   |-----------------
	|			   |	
	|			   |
	|              |
	|	           |
	----------------

TODO:
- Complete the method todetermine whether the rectangle is wholly contained within another rectangle.