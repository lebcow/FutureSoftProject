using System;

namespace Test_2
{
    class MyRectangle
    {
        public int X1 { get; set; }

        public int X2 { get; set; }

        public int Y1 { get; set; }

        public int Y2 { get; set; }

        public bool IsWhollyContainedIn(MyRectangle otherRectangle)
        {
            // Enter your code here
            throw new NotImplementedException("You need to implement this method");
        }
    }
}