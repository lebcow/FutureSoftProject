﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_5
{
	class Program
	{
		static void Main(string[] args)
		{
			const string sentenceOne = "Hello World!";
			const string sentenceTwo = "May the Fourth, be with you.";

			const string sentenceOneReversed = "World Hello!";
			const string sentenceTwoReversed = "you with be, Fourth the May.";

			Debug.Assert((ReverseSentence(sentenceOne) == sentenceOneReversed));
			Debug.Assert((ReverseSentence(sentenceTwo) == sentenceTwoReversed));
		}

		public static string ReverseSentence(string sentence)
		{
			char[] characters = sentence.ToCharArray();

			StringBuilder reversedSentence = new StringBuilder();

			for (int i = characters.Length - 1; i > -1; i--)
			{

				reversedSentence.Append(characters[i]);
			}

			return reversedSentence.ToString();
		}
	}
}
