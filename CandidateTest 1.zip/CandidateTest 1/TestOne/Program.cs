﻿using System;
using System.Diagnostics;
using System.Text;

namespace Test_1
{
    class Program
    {
        const string testInput1 = "A Ferrari is a type of car";
        const string testOutput1 = "A irarreF si a epyt fo rac";

        const string testInput2 = "After a number of practice laps on the track, the Ferrari was ready for the main race.";
        const string testOutput2 = "retfA a rebmun fo ecitcarp spal no eht kcart, eht irarreF saw ydaer rof eht niam ecar.";

        static void Main(string[] args)
        { 
            Debug.Assert(ReverseWords(testInput1) == testOutput1, "Incorrect answer for testInput1.");
            Debug.Assert(ReverseWords(testInput2) == testOutput2, "Incorrect answer for testInput2.");
        }

        private static string ReverseWords(string input)
        {
            string[] reversedWords = input.Split(' ');
            string finalWord = string.Empty;
            string[] excludedSymbols = { ".", "," }; //irrevesable symbols
            StringBuilder sbFinalSentence = new StringBuilder();

            for (int x = 0; x < reversedWords.Length; x++)
            {
                char[] array = reversedWords[x].ToCharArray();
                Array.Reverse(array);
                finalWord = new string(array);

                if (Array.Exists(excludedSymbols, e => e.Contains(finalWord.Substring(0, 1))))
                    sbFinalSentence.Append(finalWord.Substring(1) + finalWord.Substring(0, 1) );
                else
                    sbFinalSentence.Append(finalWord);

                sbFinalSentence.Append(" ");
            }

            return sbFinalSentence.ToString().Trim();
        }
    }
}
