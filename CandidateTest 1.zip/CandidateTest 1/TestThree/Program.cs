﻿using System;
using System.Collections.Generic;
using System.Diagnostics; 
using System.Linq;

namespace Test_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] lines = Resources.NameData.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            Dictionary<string, int> counts = AggregateNames(lines);

            Debug.Assert(counts.ContainsKey("Sarah") && counts["Sarah"] == 1218);
            Debug.Assert(counts.ContainsKey("Mike") && counts["Mike"] == 1290);
            Debug.Assert(counts.ContainsKey("John") && counts["John"] == 2580);
            Debug.Assert(counts.ContainsKey("Peter") && counts["Peter"] == 1240);
            Debug.Assert(counts.ContainsKey("Robert") && counts["Robert"] == 1196);
            Debug.Assert(counts.ContainsKey("Rudi") && counts["Rudi"] == 2145);
            Debug.Assert(counts.ContainsKey("Frank") && counts["Frank"] == 1147);
        }

        private static Dictionary<string, int> AggregateNames(string[] lines)
        {
            List<string> lstNames = new List<string>(lines);
            Dictionary<string, int> names = new Dictionary<string, int>();

            var nameTotals = from x in lstNames
                    group x by x into g
                    let count = g.Count()
                    orderby count descending
                    select new { Value = g.Key, Count = count };

            foreach (var x in nameTotals)
            {
                names.Add(x.Value, x.Count); 
            }

            return names; 
        } 
    }
}
