﻿Test 3
======

In this test you need to count the number of times names appear in a given array.
The return is a dictionary of all names and the number of times they appear in the array.

TODO:
- Complete the AggregateNames method to return the dictionary
- All assert statements must pass.
