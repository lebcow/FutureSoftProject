﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_3
{
    public class Resources
    {

        public static string NameData 
        { 
            get
            {
                return GetNames(); 
            } 
            set
            {
                NameData = value;
            } 
        }


        public static String GetNames()
        {
            string names = "";
            string filePath = "C:/Resources.txt";
            if (File.Exists(filePath))
            {
                using (StreamReader streamReader = new StreamReader(filePath))
                {
                    names = streamReader.ReadToEnd();
                }
            }
            else
            {
                File.Create("C:/Resources");
                using (StreamWriter streamWriter = new StreamWriter("C:/Resources.txt"))
                {
                    for (int i = 0; i < 1218; i++)
                    {
                        streamWriter.Write("Sarah\r\n");
                    }
                    for (int i = 0; i < 1290; i++)
                    {
                        streamWriter.Write("Mike\r\n");
                    }
                    for (int i = 0; i < 2580; i++)
                    {
                        streamWriter.Write("John\r\n");
                    }
                    for (int i = 0; i < 1240; i++)
                    {
                        streamWriter.Write("Peter\r\n");
                    }
                    for (int i = 0; i < 1196; i++)
                    {
                        streamWriter.Write("Robert\r\n");
                    }
                    for (int i = 0; i < 2145; i++)
                    {
                        streamWriter.Write("Rudi\r\n");
                    }
                    for (int i = 0; i < 1147; i++)
                    {
                        streamWriter.Write("Frank\r\n");
                    }
                }
                GetNames();
            }
            return names;
        }
    }

}
